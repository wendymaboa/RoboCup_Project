import numpy as np
import math


def cover_zeros(matrix):
    n, m = matrix.shape
    covered_rows = np.zeros(n, dtype=bool)
    covered_cols = np.zeros(m, dtype=bool)
    marked = np.zeros((n, m), dtype=int)  # 1 for starred zeros, 2 for primed zeros

    # Step 1: Star all zeros that are the only zero in their row or column
    for i in range(n):
        for j in range(m):
            if matrix[i, j] == 0 and not covered_rows[i] and not covered_cols[j]:
                marked[i, j] = 1  # Star the zero
                covered_rows[i] = True
                covered_cols[j] = True

    # Reset the covers
    covered_rows[:] = False
    covered_cols[:] = False

    return marked, covered_rows, covered_cols

def find_assignments(matrix):
    n, m = matrix.shape
    marked, covered_rows, covered_cols = cover_zeros(matrix)
    
    def cover_columns_with_starred_zero():
        for i in range(n):
            for j in range(m):
                if marked[i, j] == 1:
                    covered_cols[j] = True

    def find_a_zero():
        for i in range(n):
            if not covered_rows[i]:
                for j in range(m):
                    if matrix[i, j] == 0 and not covered_cols[j]:
                        return i, j
        return -1, -1

    def find_star_in_row(row):
        for j in range(m):
            if marked[row, j] == 1:
                return j
        return -1

    def find_star_in_col(col):
        for i in range(n):
            if marked[i, col] == 1:
                return i
        return -1

    def find_prime_in_row(row):
        for j in range(m):
            if marked[row, j] == 2:
                return j
        return -1

    def augment_path(path):
        for (i, j) in path:
            if marked[i, j] == 1:
                marked[i, j] = 0
            else:
                marked[i, j] = 1

    def erase_primes():
        marked[marked == 2] = 0

    # Step 2: Cover columns with a starred zero
    cover_columns_with_starred_zero()

    while True:
        # Step 3: Check if all columns are covered
        if np.all(covered_cols):
            break

        # Step 4: Find a non-covered zero and prime it
        row, col = find_a_zero()
        while row != -1:
            marked[row, col] = 2  # Prime the zero
            star_col = find_star_in_row(row)
            if star_col != -1:
                # Starred zero found in the row, cover the row and uncover the column
                covered_rows[row] = True
                covered_cols[star_col] = False
            else:
                # No starred zero in the row, proceed to step 5
                # Construct a series of alternating primed and starred zeros
                path = [(row, col)]
                while True:
                    star_row = find_star_in_col(col)
                    if star_row == -1:
                        break
                    path.append((star_row, col))
                    prime_col = find_prime_in_row(star_row)
                    path.append((star_row, prime_col))
                    col = prime_col

                augment_path(path)
                erase_primes()
                covered_rows[:] = False
                covered_cols[:] = False
                cover_columns_with_starred_zero()
                break
            row, col = find_a_zero()

        else:
            # Step 6: Adjust the matrix
            min_uncovered = np.min(matrix[~covered_rows][:, ~covered_cols])
            matrix[~covered_rows] -= min_uncovered
            matrix[:, covered_cols] += min_uncovered

    # Step 7: Prepare the assignment
    assignments = [-1] * n
    for i in range(n):
        for j in range(m):
            if marked[i, j] == 1:
                assignments[i] = j
                break

    return assignments

import numpy as np
import math

def role_assignment(teammate_positions, formation_positions): 
    n = len(teammate_positions)
    m = len(formation_positions)
    size = max(n, m)
    max_cost = 1e6  # A large finite number
    cost_mat = np.full((size, size), max_cost)  # Initialize with a large number

    for i in range(n):
        curr_pos = teammate_positions[i]
        if curr_pos is None:
            continue  # Skip if teammate position is None

        for j in range(m):
            for_pos = formation_positions[j]
            if for_pos is None:
                continue  # Skip if formation position is None

            distance = math.hypot(for_pos[0] - curr_pos[0], for_pos[1] - curr_pos[1])
            cost_mat[i, j] = distance

    # Steps 2 and 3: Subtract Row and Column Minimums
    row_min = np.min(cost_mat, axis=1)
    cost_mat = cost_mat - row_min[:, np.newaxis]

    col_min = np.min(cost_mat, axis=0)
    cost_mat = cost_mat - col_min

    # Steps 4-6: Apply the Hungarian Algorithm
    assignments = find_assignments(cost_mat.copy())

    # Prepare the result dictionary with NumPy arrays
    result = {}
    for i, j in enumerate(assignments):
        if i < n and j != -1 and j < m:
            result[i + 1] = np.array(formation_positions[j])  # Convert to NumPy array

    return result



import math

def pass_reciever_selector(player_unum, teammate_positions, final_target):
    """
    Selects the nearest teammate to pass the ball forward.
    
    Args:
        player_unum (int): The uniform number of the player with the ball (1-indexed).
        teammate_positions (list): List of (x, y) positions of all teammates (None if absent).
        final_target (tuple): The final target position for the pass.
        
    Returns:
        tuple: The target position of the nearest forward player or the final target.
    """

    current_pos = teammate_positions[player_unum - 1]  # Convert 1-index to 0-index
    if current_pos is None:
        return final_target  # If current player position is None, pass to the final target

    min_distance = float('inf')
    nearest_player = None

    # Iterate over all teammates to find the nearest forward player
    for i, pos in enumerate(teammate_positions):
        if i != player_unum - 1 and pos is not None:  # Ignore current player and absent teammates
            # Only consider players positioned further along the x-axis (forward)
            if pos[0] > current_pos[0]:
                distance = math.hypot(pos[0] - current_pos[0], pos[1] - current_pos[1])
                if distance < min_distance:
                    min_distance = distance
                    nearest_player = pos

    # If no forward player is available, pass to the final target
    return nearest_player if nearest_player is not None else final_target

