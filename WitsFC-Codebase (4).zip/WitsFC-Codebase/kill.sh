#!/bin/bash
pkill -9 -e -f "python3 ./Run_"
